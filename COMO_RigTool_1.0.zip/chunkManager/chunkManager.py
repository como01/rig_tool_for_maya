# -*- coding: utf-8 -*-

'''
Created on 2020/10/02

@author: zokuz
'''

import maya.cmds as cmds
from comoMessage import comoMessage

level = comoMessage.messageLevel

class ChunkManager():

    def __init__(self):
        self.openCunkFlg = False
        self.undoTrigger = False
        self.chunkName = ''

    def onUndoTrigger(self):
        self.undoTrigger = True

    def openChunk(self, chunkName = ''):
        comoMessage.printDebugMessage('Call Open Chunk', self.chunkName, level)
        if not self.openCunkFlg:
            self.openCunkFlg = True
            self.chunkName = chunkName
            cmds.undoInfo(openChunk = True, chunkName = chunkName)
            comoMessage.printDebugMessage('Open Chunk', self.chunkName, level)

    def closeChunk(self):
        comoMessage.printDebugMessage('Call Close Chunk', self.chunkName, level)
        if self.openCunkFlg:
            self.openCunkFlg = False
            cmds.undoInfo(closeChunk = True, chunkName = self.chunkName)
            comoMessage.printDebugMessage('Close Chunk', self.chunkName, level)

    def closeChunkUndo(self):
        self.closeChunk()
        if self.undoTrigger:
            cmds.undo()
