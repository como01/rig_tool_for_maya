# -*- coding: utf-8 -*-

'''
COMO Tool userSetup
'''

from maya import cmds
from comoToolPyside2 import mayaToolMenu
from comoMessage import comoMessage

level = comoMessage.messageLevel

comoMessage.printInfoMessage('mayaTool_gum loaded.', level)

mayaToolMenu.main()
