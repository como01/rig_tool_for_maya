# -*- coding: utf-8 -*-

'''
引数エラー
'''
class ArgumentError(Exception):
    pass