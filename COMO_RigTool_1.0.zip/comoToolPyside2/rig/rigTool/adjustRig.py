# -*- coding: utf-8 -*-

'''
COMO Tool adjustRig
'''

from maya import cmds
from comoToolPyside2.rig import comoUtil
from comoToolPyside2.rig.rigTool import rigTool
from comoToolPyside2.rig.otherTool import otherTool
from comoMessage import comoMessage
from chunkManager.chunkManager import ChunkManager

level = comoMessage.messageLevel

'''
選択オブジェクトを任意の方向に移動します
'''
def adjustTranslate(spaceSuffix, direction, distance = 0):
    chunk = ChunkManager()
    chunk.openChunk('adjustTranslate')
    try:
        rigList = comoUtil.removeWithParameter(cmds.ls(sl = True, transforms = True), spaceSuffix)
        comoMessage.printDebugMessage('rigList', rigList, level)
        if rigList:
            constraint = ''
            joint = ''
            point = False
            childrensList = []
            jointList = []
            for rig in rigList:
                childrensList.append(comoUtil.parentChildrenToWorld(rig))
                constraintInfo = comoUtil.getConstraint(rig)
                comoMessage.printDebugMessage('constraintInfo', constraintInfo, level)
                constraint = constraintInfo.get('constraint')
                if constraint:
                    joint = cmds.listConnections(constraint)[0]
                    comoMessage.printDebugMessage('joint', joint, level)
                    jointList.append(joint)
                    point = constraintInfo.get('point')
                    comoUtil.releaseConstraint(rig, joint, point = point)

            for rig, joint, childrens in zip(rigList, jointList, childrensList):
                for i, t in enumerate(cmds.xform(rig, q = True, translation = True, worldSpace = True)):
                    comoMessage.printDebugMessage('translate', t, level)
                    if direction == 'x' and i == 0:
                        cmds.move(distance + t, rig, moveX = True)
                    elif direction == 'y' and i == 1:
                        cmds.move(distance + t, rig, moveY = True)
                    elif direction == 'z' and i == 2:
                        cmds.move(distance + t, rig, moveZ = True)
                    chunk.onUndoTrigger()
                comoUtil.freezeTRS(rig, True, False, False)
                rigTool.alignRigPivotToJoint(rig, joint)
                comoUtil.parentChildren(rig, childrens)

            if constraint:
                for rig, joint in zip(rigList, jointList):
                    comoUtil.setConstraint(rig, joint, point = point)
            cmds.select(rigList)
        else:
            comoMessage.printInfoMessage('Please select Transforms.', level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('adjustTranslate', e, level)
    chunk.closeChunk()

'''
選択オブジェクトの位置をJointに合わせます
'''
def translateReset(spaceSuffix):
    chunk = ChunkManager()
    chunk.openChunk('translateReset')
    try:
        rigList = comoUtil.removeWithParameter(cmds.ls(sl = True, transforms = True), spaceSuffix)
        comoMessage.printDebugMessage('rigList', rigList, level)
        if rigList:
            for rig in rigList:
                constraintInfo = comoUtil.getConstraint(rig)
                comoMessage.printDebugMessage('constraintInfo', constraintInfo, level)
                constraint = constraintInfo.get('constraint')
                if constraint:
                    joint = cmds.listConnections(constraint)[0]
                    comoMessage.printDebugMessage('joint', joint, level)
                    point = constraintInfo.get('point')
                    orient = constraintInfo.get('orient')
                    comoUtil.releaseConstraint(rig, joint, point = point, orient = orient)
                    chunk.onUndoTrigger()
                    childrenList = comoUtil.parentChildrenToWorld(rig)

                    otherTool.centerPivot(rig)
                    con = cmds.parentConstraint(joint, rig)
                    cmds.delete(con)

                    comoUtil.freezeTRS(rig, True, False, False)
                    comoUtil.parentChildren(rig, childrenList)
                    comoUtil.setConstraint(rig, joint, point = point, orient = orient)
            cmds.select(rigList)
        else:
            comoMessage.printInfoMessage('Please select Transforms.', level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('translateReset', e, level)
    chunk.closeChunk()

'''
選択オブジェクトを回転します
'''
def adjustRotate(spaceSuffix, rotate, x = False, y = False, z = False):
    chunk = ChunkManager()
    chunk.openChunk('adjustRotate')
    try:
        rigList = comoUtil.removeWithParameter(cmds.ls(sl = True, transforms = True), spaceSuffix)
        comoMessage.printDebugMessage('rigList', rigList, level)
        if rigList:
            for rig in rigList:
                childrenList = comoUtil.parentChildrenToWorld(rig)
                chunk.onUndoTrigger()
                comoMessage.printDebugMessage('childrenList', childrenList, level)
                if x:
                    cmds.rotate(rotate, rig, rotateX = x)
                elif y:
                    cmds.rotate(rotate, rig, rotateY = y)
                elif z:
                    cmds.rotate(rotate, rig, rotateZ = z)
                comoUtil.freezeTRS(rig, False, True, False)
                comoUtil.parentChildren(rig, childrenList)
            cmds.select(rigList)
        else:
            comoMessage.printInfoMessage('Please select Transforms.', level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('adjustRotate', e, level)
    chunk.closeChunk()

'''
選択オブジェクトのスケールを変更します
'''
def adjustScale(spaceSuffix, scale):
    chunk = ChunkManager()
    chunk.openChunk('adjustScale')
    try:
        rigList = comoUtil.removeWithParameter(cmds.ls(sl = True, transforms = True), spaceSuffix)
        comoMessage.printDebugMessage('rigList', rigList, level)
        if rigList:
            for rig in rigList:
                comoMessage.printDebugMessage('rig', rig, level)
                childrenList = comoUtil.parentChildrenToWorld(rig)
                chunk.onUndoTrigger()
                cmds.scale(scale, scale, scale, rig)
                comoUtil.freezeTRS(rig, translate = False, rotate = False)
                comoUtil.parentChildren(rig, childrenList)
            cmds.select(rigList)
        else:
            comoMessage.printInfoMessage('Please select Transforms.', level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('adjustScale', e, level)
    chunk.closeChunk()
