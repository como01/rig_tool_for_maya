# -*- coding: utf-8 -*-

'''
COMO Tool rigTool
'''

from maya import cmds
from comoToolPyside2.rig import comoUtil
from comoToolPyside2.rig.comoToolIcon import createIcon
from chunkManager.chunkManager import ChunkManager
from comoMessage import comoMessage
from comoToolPyside2.rig.otherTool.otherTool import centerPivot

level = comoMessage.messageLevel

'''
rigのsetを作成します
'''
def createRigSet(rootRig, rigSuffix, spaceSuffix):
    cmds.sets(comoUtil.getRigList(rootRig, rigSuffix, spaceSuffix), name = 'rigSet')

'''
rigのpivotをjointに合わせます
'''
def alignRigPivotToJoint(rig = '', joint = ''):
    def xform(joint, rig = ''):
        if not rig:
            targetList = cmds.orientConstraint(joint, q = True, targetList = True)
            if targetList:
                rig = targetList[0]
            else:
                targetList = cmds.pointConstraint(joint, q = True, targetList = True)
                if targetList:
                    rig = targetList[0]
                else:
                    targetList = cmds.parentConstraint(joint, q = True, targetList = True)
                    if targetList:
                        rig = targetList[0]
                    else:
                        comoMessage.printInfoMessage('Not Rig and Constraint.', level)

        if rig:
            cmds.xform(rig, rp = (jointPivot[0], jointPivot[1], jointPivot[2]), ws = True)

    chunk = ChunkManager()
    chunk.openChunk('alignRigPivotToJoint')
    try:
        if joint:
            jointPivot = cmds.xform(joint, q = True, rp = True, ws = True)
            xform(joint, rig)
        else:
            jointList = cmds.ls(type = 'joint')
            if jointList:
                for joint in jointList:
                    jointPivot = cmds.xform(joint, q = True, rp = True, ws = True)
                    xform(joint)
            xform(joint)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('alignRigPivotToJoint', e, level)
    chunk.closeChunk()

'''
選択したrigと同名のjoint、もしくはjointと同名のrigをconstraintします
'''
def setConstraint(rootRig, rigSuffix, spaceSuffix, dummyJointSuffix, parent = False, point = False, orient = False):
    chunk = ChunkManager()
    chunk.openChunk('setConstraint')
    try:
        objList = cmds.ls(sl = True)
        if objList:
            for obj in objList:
                if cmds.objectType(obj, isType = 'joint'):
                    rigList = comoUtil.getRigList(rootRig, rigSuffix, spaceSuffix)
                    if rigList:
                        for rig in rigList:
                            if obj.replace(dummyJointSuffix, '', 1) == rig.replace(rigSuffix, '', 1):
                                comoUtil.setConstraint(rig, obj, parent, point, orient)
                elif cmds.objectType(obj, isType = 'transform') and not obj.endswith(spaceSuffix):
                    jointList = cmds.ls(type = 'joint')
                    if jointList:
                        for joint in jointList:
                            if obj.replace(rigSuffix, '', 1) == joint.replace(dummyJointSuffix, '', 1):
                                comoUtil.setConstraint(obj, joint, parent, point, orient)
                else:
                    comoMessage.printInfoMessage('Please select Rig or Joint.', level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('setConstraint', e, level)
    chunk.closeChunk()

'''
アイコンを作成します

    <Joint選択>
        選択Jointと同位置にアイコンを作成
        Spaceを作成してparentします

    <allJoint>
        リファレンスを除く全てのJointを選択します

    <copyHierarchy>
        選択Jointの階層構造をコピーします

    <各種constraint>
        選択Jointに対してコンストレインします

    <change>
        選択したRigの形を変更します
'''
def selectIcon(root, rigSuffix, spaceSuffix, dummyJointSuffix, selIcon = 'Circle', scale = 1, allJoint = False, copyHierarchy = False, parent = False, point = False, orient = False, change = False, ):
    space = ''
    rig = ''
    returnList = []
    chunk = ChunkManager()
    chunk.openChunk('selectIcon')
    try:
        #既存のRigを変更
        if change:
            rigList = comoUtil.removeWithParameter(cmds.ls(sl = True, transforms = True), spaceSuffix)
            comoMessage.printDebugMessage('rigList', rigList, level)
            if rigList:
                for rig in rigList:
                    rootFlg = False
                    joint = ''
                    constraintInfo = comoUtil.getConstraint(rig)
                    comoMessage.printDebugMessage('constraintInfo', constraintInfo, level)
                    constraint = constraintInfo.get('constraint')

                    if constraint:
                        joint = cmds.listConnections(constraint)[0]
                        comoMessage.printDebugMessage('joint', joint, level)
                        comoUtil.releaseConstraint(rig, joint, constraintInfo.get('parent'), constraintInfo.get('point'), constraintInfo.get('orient'))
                        chunk.onUndoTrigger()
                        if root in joint:
                            rootFlg = True

                    childrenList = comoUtil.parentChildrenToWorld(rig)
                    chunk.onUndoTrigger()
                    comoMessage.printDebugMessage('childrenList', childrenList, level)
                    if rootFlg:
                        icon = createIcon(selIcon, scale)
                    else:
                        icon = createIcon(selIcon, scale, rotate = 90, z = True)

                    centerPivot(rig)
                    con = cmds.parentConstraint(rig, icon)
                    cmds.delete(con)
                    alignRigPivotToJoint(icon, joint)

                    rigParentList = cmds.listRelatives(rig, parent = True)
                    comoMessage.printDebugMessage('rigParentList', rigParentList, level)
                    if rigParentList:
                        cmds.parent(icon, rigParentList[0])
                    comoUtil.parentChildren(icon, childrenList)

                    if joint:
                        comoUtil.setConstraint(icon, joint, constraintInfo.get('parent'), constraintInfo.get('point'), constraintInfo.get('orient'))
                    cmds.delete(rig)

                    cmds.rename(icon, rig)
                    returnList.append({'rig': rig, 'space': space})
                cmds.select(rigList)
            else:
                comoMessage.printInfoMessage('Select Rig to change.', level)
        else:
            if allJoint:
                selList = cmds.ls(type = 'joint')
                objList = comoUtil.removeRefJoint(selList)
                objList = comoUtil.removeChildless(objList)
                comoMessage.printDebugMessage('objList', objList, level)
            else:
                selList = cmds.ls(sl = True, transforms = True)
                objList = comoUtil.removeConstraint(selList)
                comoMessage.printDebugMessage('objList', objList, level)

            if objList:
                sortList = []
                for obj in objList:
                    rootFlg = False
                    if root in obj:
                        rootFlg = True
                    if rootFlg:
                        rig = createIcon(selIcon, scale, name = ''.join([obj.replace(dummyJointSuffix, ''), rigSuffix]))
                    else:
                        rig = createIcon(selIcon, scale, name = ''.join([obj.replace(dummyJointSuffix, ''), rigSuffix]), rotate = 90, z = True)
                    chunk.onUndoTrigger()
                    space = cmds.createNode('transform', name = ''.join([rig, spaceSuffix]))
                    comoMessage.printDebugMessage('rig', rig, level)
                    comoMessage.printDebugMessage('space', space, level)
                    cmds.parent(rig, space)
                    con = cmds.parentConstraint(obj, space)
                    cmds.delete(con)
                    comoUtil.setConstraint(rig, obj, parent, point, orient)

                    if copyHierarchy:
                        parentList = cmds.listRelatives(obj, parent = True, fullPath = True)
                        if parentList:
                            parentPath = parentList[0]
                        else:
                            parentPath = ''
                        sortList.append({'parent': parentPath, 'obj': obj, 'rigSet': {'rig': rig, 'space': space}})
                sortList.sort(key = lambda x: x.get('parent'))
                comoMessage.printDebugMessage('sortList', sortList, level)

                if sortList:
                    prevObjsList = []
                    for objs in sortList:
                        if prevObjsList:
                            for prevObjs in prevObjsList:
                                if prevObjs.get('obj') == comoUtil.getNodeList(objs.get('parent'))[-1]:
                                    cmds.parent(objs.get('rigSet').get('space'), prevObjs.get('rigSet').get('rig'))
                        prevObjsList.append(objs)
                    returnList.append({'rig': rig, 'space': space})
            else:
                rig = createIcon(selIcon, scale)
                chunk.onUndoTrigger()
                space = cmds.createNode('transform', name = ''.join([rig,  spaceSuffix]))
                cmds.parent(rig, space)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('selectIcon', e, level)
    chunk.closeChunk()
    if returnList:
        return returnList
    else:
        return {'rig': rig, 'space': space}
