# -*- coding: utf-8 -*-

'''
COMO Tool jointTool
'''

from maya import cmds
from comoToolPyside2.rig import comoUtil
from chunkManager.chunkManager import ChunkManager
from comoMessage import comoMessage

level = comoMessage.messageLevel

'''
dummyJointにjointをペアレントします
'''
def parentJointToDummy(dummyJointSuffix, dummyJointList = [], refJointList = []):
    chunk = ChunkManager()
    chunk.openChunk('parentJointToDummy')
    try:
        if not dummyJointList:
            cmds.select(''.join(['*', dummyJointSuffix]))
            dummyJointList = cmds.ls(sl = True, type = 'joint')
        comoMessage.printDebugMessage('dummyJointList', dummyJointList, level)

        if not refJointList:
            try:
                cmds.select(''.join(['*', comoUtil.referenceSplit, '*']))
                refJointList = cmds.ls(sl = True, type = 'joint')
            except ValueError:
                refJointList = comoUtil.removeWithParameter(cmds.ls(type = 'joint'), dummyJointSuffix)
        comoMessage.printDebugMessage('refJointList', refJointList, level)
        cmds.select(clear = True)

        if dummyJointList and refJointList:
            [cmds.parentConstraint(dummyJoint, refJoint) for dummyJoint in dummyJointList for refJoint in refJointList
             if dummyJoint.split(dummyJointSuffix)[0] == refJoint.split(comoUtil.referenceSplit)[-1]]
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('parentJointToDummy', e, level)
    chunk.closeChunk()

'''
ReferenceJointをコピーしてDummyJointを作成します
全てのdummyJointとrefJointをペアレントします
ReferenceJointがない場合は既存のJointのDummyJointを作成ペアレントします
'''
def createDummyJoint(dummyJointSuffix):
    chunk = ChunkManager()
    chunk.openChunk('createDummyJoint')
    try:
        refJointList = []
        cmds.select(''.join(['*', comoUtil.referenceSplit, '*']))
        refJointList = cmds.ls(sl = True, type = 'joint')
    except ValueError:
        refJointList = cmds.ls(type = 'joint')
    try:
        comoMessage.printDebugMessage('refJointList', refJointList, level)
        if refJointList:
            dummyJointList = []
            duplicateList = cmds.duplicate(refJointList, renameChildren = True)
            chunk.onUndoTrigger()
            if duplicateList:
                for refJoint, dummyJoint in zip(refJointList, duplicateList):
                    dummyJointList.append(cmds.rename(dummyJoint, ''.join([refJoint.split(comoUtil.referenceSplit)[-1], dummyJointSuffix])))
            comoMessage.printDebugMessage('dummyJointList', dummyJointList, level)
            parentJointToDummy(dummyJointSuffix, dummyJointList, refJointList)
            cmds.createDisplayLayer(dummyJointList, name = 'layerDummyJoint')
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('createDummyJoint', e, level)
    chunk.closeChunk()

'''
子のないjointのローカル軸を親jointに合わせます
'''
def orientEndJoint():
    chunk = ChunkManager()
    chunk.openChunk('orientEndJoint')
    try:
        jointList = cmds.ls(type = 'joint')
        targetJointList = comoUtil.removeHaveChildrenElement(jointList)
        if targetJointList:
            for targetJoint in targetJointList:
                targetJointSpace = cmds.listRelatives(targetJoint, parent = True)[0]
                targetJointT = cmds.xform(targetJoint, q = True, t = True, ws = True)
                con = cmds.parentConstraint(targetJointSpace, targetJoint)
                chunk.onUndoTrigger()
                cmds.delete(con)
                cmds.xform(targetJoint, t = (targetJointT[0], targetJointT[1], targetJointT[2]), ws = True)
                cmds.makeIdentity(targetJoint, apply = True)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('orientEndJoint', e, level)
    chunk.closeChunk()
