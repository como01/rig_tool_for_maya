# -*- coding: utf-8 -*-

'''
COMO Tool otherTool
'''

from maya import cmds
from comoToolPyside2.rig import comoUtil
from chunkManager.chunkManager import ChunkManager
from comoMessage import comoMessage

level = comoMessage.messageLevel

'''
選択オブジェクトのピボットをセンターに移動します
'''
def centerPivot(obj = ''):
    def xform(obj):
        childrenList = comoUtil.parentChildrenToWorld(obj)
        comoMessage.printDebugMessage('childrenList', childrenList, level)
        chunk.onUndoTrigger()
        cmds.xform(obj, centerPivots = True)
        comoUtil.parentChildren(obj, childrenList)

    chunk = ChunkManager()
    chunk.openChunk('centerPivot')
    try:
        if obj:
            xform(obj)
        else:
            objList = cmds.ls(sl = True, transforms = True)
            comoMessage.printDebugMessage('objList', objList, level)
            if objList:
                for obj in objList:
                    xform(obj)
            else:
                comoMessage.printInfoMessage('Please select Transforms.', level)
            cmds.select(objList)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('centerPivot', e, level)
    chunk.closeChunk()

'''
選択オブジェクトを指定色に変更します
'''
def changeColor(color, spaceSuffix, outliner = False):
    chunk = ChunkManager()
    chunk.openChunk('changeColor')
    try:
        selList = cmds.ls(sl = True, type = 'transform')
        comoMessage.printDebugMessage('selList', selList, level)
        if selList:
            for sel in selList:
                space = ''
                if spaceSuffix in sel:
                    space = sel
                    rig = cmds.listRelatives(sel, type = 'transform')[0]
                else:
                    spaceList = cmds.listRelatives(sel, parent = True, type = 'transform')
                    if spaceList:
                        spaceList0 = spaceList[0]
                        if spaceSuffix in spaceList0:
                            space = spaceList0
                    rig = sel
                comoMessage.printDebugMessage('space', space, level)
                comoMessage.printDebugMessage('rig', rig, level)
                childrenList = cmds.listRelatives(rig, type = 'transform')
                setColorAttr(rig, color, outliner, childrenList)
                chunk.onUndoTrigger()
                if space:
                    setColorAttr(space, color, outliner)
        else:
            comoMessage.printInfoMessage('Please select Transforms.', level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('changeColor', e, level)
    chunk.closeChunk()

'''
選択オブジェクトを指定色に変更します
'''
def setColorAttr(obj, color, outliner = False, childrenList = []):
    if childrenList:
        for children in childrenList:
            #子に独自カラーを持たせる
            cmds.setAttr('.'.join([children, 'overrideEnabled']), True)
    if color == 0:
        cmds.setAttr('.'.join([obj, 'useOutlinerColor']), False)
    cmds.setAttr('.'.join([obj, 'overrideEnabled']), True)
    cmds.setAttr('.'.join([obj, 'overrideRGBColors']), False)
    cmds.setAttr('.'.join([obj, 'overrideColor']), color)
    if outliner:
        rgb = cmds.colorIndex(color, q = True)
        cmds.setAttr('.'.join([obj, 'useOutlinerColor']), True)
        cmds.setAttr('.'.join([obj, 'outlinerColor']), rgb[0], rgb[1], rgb[2])
