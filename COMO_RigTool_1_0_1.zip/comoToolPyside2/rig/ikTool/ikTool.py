# -*- coding: utf-8 -*-

'''
COMO Tool ikTool
'''

from maya import cmds
from comoToolPyside2.rig import comoUtil
from comoToolPyside2.rig.rigTool import rigTool
from comoToolPyside2.rig.comoToolIcon import createIcon
from error.error import ArgumentError
from chunkManager.chunkManager import ChunkManager
from comoMessage import comoMessage

level = comoMessage.messageLevel

reverseFootNamePrefix = 'rf_'

'''
Suffixで検索したJointにIkHandleを設定します
'''
def createIk(startJointSuffix, endJointSuffix, ikSuffix, solver = 'ikRPsolver'):
    chunk = ChunkManager()
    chunk.openChunk('createIk')
    try:
        cmds.select(''.join(['*', startJointSuffix]))
        jointList = cmds.ls(sl = True, type = 'joint')
        if jointList:
            selectList = []
            for startJoint in jointList:
                selectList.append(cmds.ikHandle(name = ''.join([startJoint, ikSuffix]), startJoint = startJoint, endEffector = ''.join([startJoint.replace(startJointSuffix, ''), endJointSuffix]), solver = solver)[0])
                chunk.onUndoTrigger()
            comoMessage.printDebugMessage('selectList', selectList, level)
            cmds.select(selectList)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('createIk', e, level)
    chunk.closeChunk()

'''
ikHandleのendJointとorientConstraintされているrigにpointConstraintします
ikHandleと作成したiconをpoleVecterConstraintしsecondJointの位置に配置します
選択されたikHandleがない場合は全てのikHandleを対象とします
'''
def createIkRig(rootRig, spaceSuffix, dummyJointSuffix, poleSuffix, scale = 1, rootVerFlg = False, poleIcon = 'Octahedron'):
    chunk = ChunkManager()
    chunk.openChunk('createIkRig')
    try:
        ikList = cmds.ls(sl = True, type = 'ikHandle')
        if not ikList:
            ikList = cmds.ls(type = 'ikHandle')
        if ikList:
            for ik in ikList:
                if cmds.ikHandle(ik, q = True, name = True):
                    ikJointList = cmds.ikHandle(ik, q = True, jointList = True)
                    firstJoint = ikJointList[0]
                    secondJoint = ikJointList[1]
                    endJoint = cmds.listRelatives(secondJoint, fullPath = True, type = 'joint')[0]
                    parentJoint = cmds.listRelatives(firstJoint, parent = True)[0]
                    try:
                        firstRig = cmds.orientConstraint(firstJoint, q = True, targetList = True)[0]
                        endRig = cmds.orientConstraint(endJoint, q = True, targetList = True)[0]
                        parentRig = cmds.orientConstraint(parentJoint, q = True, targetList = True)[0]
                    except:
                        try:
                            firstRig = cmds.parentConstraint(firstJoint, q = True, targetList = True)[0]
                            endRig = cmds.parentConstraint(endJoint, q = True, targetList = True)[0]
                            parentRig = cmds.parentConstraint(parentJoint, q = True, targetList = True)[0]
                        except:
                            raise ArgumentError('No OrientConstraint or ParentConstraint.')

                    firstSpace = cmds.listRelatives(firstRig, parent = True)[0]
                    endSpace = cmds.listRelatives(endRig, parent = True)[0]

                    #ikの不要なRigを削除
                    cmds.parent(endSpace, parentRig)
                    chunk.onUndoTrigger()
                    cmds.delete(firstSpace)

                    if rootVerFlg:
                        cmds.parent(endSpace, rootRig)
                    cmds.parent(ik, parentJoint)
                    cmds.pointConstraint(endRig, ik)

                if cmds.ikHandle(ik, q = True, solver = True) == 'ikRPsolver':
                    #poleVectorRigを作成する
                    if not cmds.poleVectorConstraint(ik, q = True, targetList = True):
                        poleRig = ''.join([firstJoint.replace(dummyJointSuffix, '', 1), poleSuffix])
                        poleRigSpace = ''.join([poleRig, spaceSuffix])
                        createIcon(poleIcon, scale, poleRig)
                        cmds.createNode('transform', name = poleRigSpace)
                        cmds.parent(poleRig, poleRigSpace)
                        con = cmds.parentConstraint(secondJoint, poleRigSpace)
                        cmds.delete(con)
                        cmds.xform(poleRigSpace, ro = (0, 0, 0), ws = True)
                        cmds.poleVectorConstraint(poleRig, ik)

                    if rootVerFlg:
                        cmds.parent(poleRigSpace, endRig)
                    else:
                        cmds.parent(poleRigSpace, parentRig)

                    #Worningを検出しないようにする
                    cmds.cycleCheck('*.parentInverseMatrix[0]', evaluation = False)
        else:
            comoMessage.printInfoMessage('Please select or create ikHandle.', level)
    except ArgumentError as ae:
        comoMessage.printInfosMessage('createIkRig', ae, level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('createIkRig', e, level)
    chunk.closeChunk()

'''
足のjointにreversFoot用のIkとrigを作成します
joint命名規則は下記の通りとします
股関節:leg
足首:ankle
足指付け根:foot
つま先:toe
踵:heel
'''
def createReverseFoot(root, legJointSuffix, kneeJointSuffix, ankleJointSuffix, footJointSuffix, toeJointSuffix, heelJointSuffix, rigSuffix, spaceSuffix, dummyJointSuffix, ikSuffix, poleSuffix, scale = 1.0):
    chunk = ChunkManager()
    chunk.openChunk('createReverseFoot')

    try:
        cmds.select(''.join(['*', legJointSuffix]))
        legJointList = cmds.ls(sl = True, type = 'joint')
        rootRig = ''.join([root, rigSuffix])

        if legJointList:
            for legJoint in legJointList:
                prefix = legJoint.replace(legJointSuffix, '')
                kneeJoint = ''.join([prefix,  kneeJointSuffix])
                ankleJoint = ''.join([prefix, ankleJointSuffix])
                footJoint = ''.join([prefix, footJointSuffix])
                toeJoint = ''.join([prefix, toeJointSuffix])
                heelJoint = ''.join([prefix, heelJointSuffix])

                ikLeg = ''.join([legJoint, ikSuffix])
                ikAnkle = ''.join([ankleJoint, ikSuffix])
                ikFoot = ''.join([footJoint, ikSuffix])
                #股関節から足首はikRPsolver
                try:
                    cmds.ikHandle(ikLeg, q = True, name = True)
                except:
                    cmds.ikHandle(name = ikLeg, startJoint = legJoint, endEffector = ankleJoint, solver = 'ikRPsolver')
                    chunk.onUndoTrigger()
                    cmds.select(ikLeg)
                    createIkRig(rootRig, spaceSuffix, dummyJointSuffix, poleSuffix, scale)
                #足首から足元、足元からつま先はikSCsolver
                cmds.ikHandle(name = ikAnkle, startJoint = ankleJoint, endEffector = footJoint, solver = 'ikSCsolver')
                chunk.onUndoTrigger()
                cmds.ikHandle(name = ikFoot, startJoint = footJoint, endEffector = toeJoint, solver = 'ikSCsolver')

                ankleT = cmds.xform(ankleJoint, q = True, t = True, ws = True)
                cmds.select(clear = True)

                #足首とつま先の交差点にheelJointを配置、その子として順につま先、足元、足首と配置する
                rfHeelJoint = cmds.joint(name = ''.join([reverseFootNamePrefix, heelJoint]))
                con = cmds.parentConstraint(toeJoint, rfHeelJoint)
                cmds.delete(con)
                cmds.xform(rfHeelJoint, t = (ankleT[0], 0, ankleT[2]), ws = True)
                comoUtil.freezeTRS(rfHeelJoint, scale = False)

                rfToeJoint = cmds.joint(name = ''.join([reverseFootNamePrefix, toeJoint]))
                con = cmds.parentConstraint(toeJoint, rfToeJoint)
                cmds.delete(con)
                comoUtil.freezeTRS(rfToeJoint, scale = False)

                rfFootJoint = cmds.joint(name = ''.join([reverseFootNamePrefix, footJoint]))
                con = cmds.parentConstraint(footJoint, rfFootJoint)
                cmds.delete(con)
                comoUtil.freezeTRS(rfFootJoint, scale = False)

                rfAnkleJoint = cmds.joint(name = ''.join([reverseFootNamePrefix, ankleJoint]))
                con = cmds.parentConstraint(ankleJoint, rfAnkleJoint)
                cmds.delete(con)
                comoUtil.freezeTRS(rfAnkleJoint, scale = False)

                #rigを作成、不要なrigとconstraintを削除、constraintする
                #ikHipJointの階層が移動する為、jointのparent前に実行すること
                cmds.select(rfHeelJoint)
                rfHeelRigInfo = rigTool.selectIcon(root, rigSuffix, spaceSuffix, dummyJointSuffix, 'Foot', scale * 2)
                rfHeelRig = rfHeelRigInfo.get('rig')
                cmds.rotate(90, 0, 90, rfHeelRig)
                cmds.makeIdentity(apply = True)
                cmds.pointConstraint(rfHeelRig, rfHeelJoint)
                cmds.orientConstraint(rfHeelRig, rfHeelJoint)

                cmds.select(rfToeJoint)
                rfToeRigInfo = rigTool.selectIcon(root, rigSuffix, spaceSuffix, dummyJointSuffix, 'Sphere', scale)
                rfToeRig = rfToeRigInfo.get('rig')
                cmds.orientConstraint(rfToeRig, rfToeJoint)

                cmds.select(rfFootJoint)
                rfFootRigInfo = rigTool.selectIcon(root, rigSuffix, spaceSuffix, dummyJointSuffix, 'Sphere', scale)
                rfFootRig = rfFootRigInfo.get('rig')
                cmds.orientConstraint(rfFootRig, rfFootJoint)

                ankleRig = cmds.orientConstraint(ankleJoint, q = True, targetList = True)[0]
                footRig = cmds.orientConstraint(footJoint, q = True, targetList = True)[0]
                cmds.delete(footRig, constraints = True)
                cmds.parentConstraint(footRig, ikFoot, maintainOffset = True)
                footRigSpace = cmds.listRelatives(footRig, parent = True)[0]
                cmds.delete(ankleRig, constraints = True)

                #jointを階層に組込む
                #heelJointをrootJointの子にし、該当のikをそれぞれrfJointの子にする
                rootJoint = comoUtil.getNodeList(cmds.listRelatives(legJoint, parent = True, fullPath = True)[0])[0]
                cmds.parent(rfHeelJoint, rootJoint)
                cmds.parent(ikLeg, rfAnkleJoint)
                cmds.parent(ikAnkle, rfFootJoint)
                cmds.parent(ikFoot, rfToeJoint)

                #rigを階層に組込む
                rfHeelRigSpace = rfHeelRigInfo.get('space')
                rfToeRigSpace = rfToeRigInfo.get('space')
                rfFootRigSpace = rfFootRigInfo.get('space')
                ankleRigSpace = cmds.listRelatives(ankleRig, parent = True)[0]
                cmds.parent(rfHeelRigSpace, rootRig)
                cmds.parent(rfToeRigSpace, rfHeelRig)
                cmds.parent(rfFootRigSpace, rfToeRig)
                cmds.parent(footRigSpace, rfToeRig)
                cmds.delete(ankleRigSpace)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('createReverseFoot', e, level)
    chunk.closeChunk()
