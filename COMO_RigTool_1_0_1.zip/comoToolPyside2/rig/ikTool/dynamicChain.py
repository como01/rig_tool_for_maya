# -*- coding: utf-8 -*-

'''
COMO Tool dynamicChain
'''

from maya import cmds
import maya.mel as mel
from chunkManager.chunkManager import ChunkManager
from comoMessage import comoMessage

level = comoMessage.messageLevel

'''
Dynamic Chainを作成する
'''
def createDynamicChain(*args):
    chunk = ChunkManager()
    chunk.openChunk('createDynamicChain')
    try:
        selJointList = cmds.ls(sl = True, type = 'joint')
        if len(selJointList) >= 2:
            firstJoint = selJointList[0]
            endJoint = selJointList[-1]

            jointList = [firstJoint]
            children = cmds.listRelatives(firstJoint, children = True, type = 'joint')[0]

            #firstJointとendJointの間にあるjointを取得
            while children != endJoint:
                jointList.append(children)
                children = cmds.listRelatives(children, children = True, type = 'joint')[0]

            jointList.append(endJoint)

            #jointの位置を取得
            jointPointList = []
            for joint in jointList:
                jointPointList.append(tuple(cmds.joint(joint, q = True, position = True)))

            #epカーブを作成
            curve = cmds.curve(editPoint = jointPointList)
            chunk.onUndoTrigger()

            #ダイナミクスカーブを作成
            cmds.select(curve)
            mel.eval('makeCurvesDynamic 2 { "1", "0", "1", "1", "0"};')

            #作成したヘアーから辿ってカーブを取得
            hairSystem = cmds.ls(sl = True)[0]
            follicle = cmds.connectionInfo('.'.join([hairSystem, 'outputHair[0]']), destinationFromSource = True)[0].split('.')[0]
            dynamicCurve = cmds.connectionInfo('.'.join([follicle, 'outCurve']), destinationFromSource = True)[0].split('.')[0]
            #スプラインIKを作成
            cmds.ikHandle(startJoint = firstJoint, endEffector = endJoint, curve = dynamicCurve, solver = 'ikSplineSolver', createCurve = False)

            #follicleのPointLockをBaseに設定
            cmds.setAttr('.'.join([follicle, 'ptl']), 1)
        else:
            comoMessage.printInfoMessage('Please select two joint.', level)
    except Exception as e:
        chunk.closeChunkUndo()
        comoMessage.printInfosMessage('createDynamicChain', e, level)
    chunk.closeChunk()

