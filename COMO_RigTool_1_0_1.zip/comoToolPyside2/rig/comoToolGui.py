# -*- coding: utf-8 -*-

'''
COMO Tool comoToolGui
'''

import os.path
from collections import OrderedDict

from maya import cmds
from maya import OpenMayaUI as omui

from PySide2.QtCore import Qt, QSettings
from PySide2.QtGui import QIcon, QStringListModel
from PySide2.QtWidgets import QWidget, QMenu, QCompleter
from PySide2.QtUiTools import QUiLoader
from shiboken2 import wrapInstance

from comoToolPyside2.rig import comoUtil
from comoToolPyside2.rig.rigTool import adjustRig
from comoToolPyside2.rig.ikTool import ikTool, dynamicChain
from comoToolPyside2.rig.rigTool import rigTool
from comoToolPyside2.rig.otherTool import otherTool, jointTool
from comoMessage import comoMessage

level = comoMessage.messageLevel


class CreateNodeUI(QWidget):

    currentDir = os.path.dirname(__file__)
    uiFilePath = os.path.join(currentDir, 'comoTool.ui')
    iniFilePath = os.path.join(currentDir, 'comoSetting.ini')
    jointSuffixHistoryFilePath = os.path.join(currentDir, 'comoSetting_001.txt')
    jointSuffixHistoryList = []
    jointSuffixHistorySep = ':'
    colorList = (1, 3, 5, 6, 9, 13, 14, 16, 17, 18, 21, 28)

    def __init__(self, *args, **kwargs):
        super(CreateNodeUI,self).__init__(*args, **kwargs)
        self.setParent(wrapInstance(long(omui.MQtUtil.mainWindow()), QWidget))
        self.setWindowFlags(Qt.Tool)
        self.setObjectName('comoToolGui')
        self.setWindowTitle('Como Tool')
        self.setGeometry(1400, 70, 430, 900)
        self.setFixedSize(430, 960)
        self.initUI()

    def initUI(self):
        #uiファイルの読み込み
        self.ui = QUiLoader().load(self.uiFilePath, parentWidget = self)

        #cmdsのスライダグループを組込む
        #Como Tool
        iconScaleSlider = cmds.floatSliderGrp('iconScaleSlider', field = True, label = 'Icon Scale ', columnWidth3 = [55, 40, 100], minValue = 1, maxValue = 50.0, value = 1.0, sliderStep = 10.0)
        self.ui.iconScaleH.insertWidget(0, wrapInstance(long(omui.MQtUtil.findControl(iconScaleSlider)), QWidget))

        adjustTranslateXSlider = cmds.intSliderGrp('adjustTranslateXSlider', field = True, label = 'X ', columnWidth3 = [10, 40, 100], minValue = -100, maxValue = 100,
                                                 value = 0, changeCommand = self.adjustTranslateX)
        self.ui.adjustTranslateV.insertWidget(0, wrapInstance(long(omui.MQtUtil.findControl(adjustTranslateXSlider)), QWidget))

        adjustTranslateYSlider = cmds.intSliderGrp('adjustTranslateYSlider', field = True, label = 'Y ', columnWidth3 = [10, 40, 100], minValue = -100, maxValue = 100,
                                                 value = 0, changeCommand = self.adjustTranslateY)
        self.ui.adjustTranslateV.insertWidget(1, wrapInstance(long(omui.MQtUtil.findControl(adjustTranslateYSlider)), QWidget))

        adjustTranslateZSlider = cmds.intSliderGrp('adjustTranslateZSlider', field = True, label = 'Z ', columnWidth3 = [10, 40, 100], minValue = -100, maxValue = 100,
                                                 value = 0, changeCommand = self.adjustTranslateZ)
        self.ui.adjustTranslateV.insertWidget(2, wrapInstance(long(omui.MQtUtil.findControl(adjustTranslateZSlider)), QWidget))

        adjustScaleSlider = cmds.floatSliderGrp('adjustScaleSlider', field = True, columnWidth2 = [40, 100], minValue = 0.1, maxValue = 5.0, value = 1.0, changeCommand = self.adjustScale)
        self.ui.adjustScaleH.insertWidget(0, wrapInstance(long(omui.MQtUtil.findControl(adjustScaleSlider)), QWidget))

        #Other
        selectColorIndexSlider = cmds.colorIndexSliderGrp('selectColorIndexSlider', min = 0, max = 32, value = 1, columnWidth2 = [50, 0])
        self.ui.selectColorH.insertWidget(0, wrapInstance(long(omui.MQtUtil.findControl(selectColorIndexSlider)), QWidget))

        selectColorSlider = cmds.intSlider('selectColorSlider', min = 0, max = 31, value = 0, width = 100, step = 1, dragCommand = lambda x: self.changeColorSlider(int(x)))
        self.ui.selectColorH.insertWidget(1, wrapInstance(long(omui.MQtUtil.findControl(selectColorSlider)), QWidget))

        palette = cmds.palettePort('palette',dim=(4,3), parent = 'selectColorG', changeCommand = lambda: self.changeColorPalette(cmds.palettePort('palette', q = True, setCurCell = True)))
        for i, color in enumerate(self.colorList):
            rgb = cmds.colorIndex(color, q = True)
            cmds.palettePort(palette, e = True, rgb = (i, rgb[0], rgb[1], rgb[2]), redraw = True)

        #HistoryMenu作成
        self.setJointSuffixHistoryMenu()

        #予測変換を設定
        completer = QCompleter(self.ui)
        completer.setModel(QStringListModel(comoUtil.getJointListExcludingReference()))
        completer.setCompletionMode(QCompleter.UnfilteredPopupCompletion)
        self.ui.legJointText.setCompleter(completer)
        self.ui.kneeJointText.setCompleter(completer)
        self.ui.ankleJointText.setCompleter(completer)
        self.ui.footJointText.setCompleter(completer)
        self.ui.toeJointText.setCompleter(completer)

        #Settingファイルの読み込み
        iniSetting = QSettings(self.iniFilePath, QSettings.IniFormat)
        #CreateRig
        if iniSetting.value('iconScaleSlider'):
            cmds.floatSliderGrp('iconScaleSlider', e = True, value = float(iniSetting.value('iconScaleSlider')))
        self.ui.allJointOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.allJointOnOff.objectName())))
        self.ui.copyHierarchyOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.copyHierarchyOnOff.objectName())))
        self.ui.parentConstraintOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.parentConstraintOnOff.objectName())))
        self.ui.pointConstraintOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.pointConstraintOnOff.objectName())))
        self.ui.orientConstraintOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.orientConstraintOnOff.objectName())))
        self.ui.changeIconOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.changeIconOnOff.objectName())))
        #IK
        self.ui.startJointSuffixText.setText(iniSetting.value(self.ui.startJointSuffixText.objectName()))
        self.ui.endJointSuffixText.setText(iniSetting.value(self.ui.endJointSuffixText.objectName()))
        self.ui.ikRPSolverRadioButton.setChecked(self.boolConverter(iniSetting.value(self.ui.ikRPSolverRadioButton.objectName())))
        self.ui.ikSCSolverRadioButton.setChecked(self.boolConverter(iniSetting.value(self.ui.ikSCSolverRadioButton.objectName())))
        self.ui.rootVersionOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.rootVersionOnOff.objectName())))
        self.ui.legJointText.setText(iniSetting.value(self.ui.legJointText.objectName()))
        self.ui.kneeJointText.setText(iniSetting.value(self.ui.kneeJointText.objectName()))
        self.ui.ankleJointText.setText(iniSetting.value(self.ui.ankleJointText.objectName()))
        self.ui.footJointText.setText(iniSetting.value(self.ui.footJointText.objectName()))
        self.ui.toeJointText.setText(iniSetting.value(self.ui.toeJointText.objectName()))
        self.ui.heelJointText.setText(iniSetting.value(self.ui.heelJointText.objectName()))
        #Other
        self.ui.translateOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.translateOnOff.objectName())))
        self.ui.rotateOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.rotateOnOff.objectName())))
        self.ui.scaleOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.scaleOnOff.objectName())))
        self.ui.outlinerOnOff.setChecked(self.boolConverter(iniSetting.value(self.ui.outlinerOnOff.objectName())))
        #Setting
        self.ui.rootText.setText(iniSetting.value(self.ui.rootText.objectName()))
        self.ui.rigSuffixText.setText(iniSetting.value(self.ui.rigSuffixText.objectName()))
        self.ui.spaceSuffixText.setText(iniSetting.value(self.ui.spaceSuffixText.objectName()))
        self.ui.dummyJointSuffixText.setText(iniSetting.value(self.ui.dummyJointSuffixText.objectName()))
        self.ui.ikSuffixText.setText(iniSetting.value(self.ui.ikSuffixText.objectName()))
        self.ui.poleVectorSuffixText.setText(iniSetting.value(self.ui.poleVectorSuffixText.objectName()))

        #buttonの色を変更
        self.ui.setStyleSheet('QPushButton{background-color: gray;}')
        #2D
        bgcolorDDDDDD = 'background-color: #DDDDDD;'
        self.ui.circleButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.crossCircleButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.circle270Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.circle180Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.square1Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.square2Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.pentagonButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.starButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.crossButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.flatCrossButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.handButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.footButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.jackButton.setStyleSheet(bgcolorDDDDDD)
        #3D
        self.ui.cubeButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.octahedronButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.sphereButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.halfSphereButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.piramidButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.piramid2Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.locatorButton.setStyleSheet(bgcolorDDDDDD)
        #Arrow
        self.ui.lineArrowButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.lineArrows2Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.lineArrows4Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.arrowButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.arrowBoldButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.arrows2Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.line90ArrowButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.lineArrows180Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.sideArrowsButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.sideArrows2Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.roundArrowsButton.setStyleSheet(bgcolorDDDDDD)
        self.ui.roundArrows2Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.arrows4Button.setStyleSheet(bgcolorDDDDDD)
        self.ui.arrows4sButton.setStyleSheet(bgcolorDDDDDD)

        #Icon画像を設定
        #2D
        flatPath = os.path.join(self.currentDir, 'iconImg', '2D')
        self.ui.circleButton.setIcon(QIcon(os.path.join(flatPath, 'Circle.jpg')))
        self.ui.crossCircleButton.setIcon(QIcon(os.path.join(flatPath, 'CrossCircle.jpg')))
        self.ui.circle270Button.setIcon(QIcon(os.path.join(flatPath, 'Circle270.jpg')))
        self.ui.circle180Button.setIcon(QIcon(os.path.join(flatPath, 'Circle180.jpg')))
        self.ui.square1Button.setIcon(QIcon(os.path.join(flatPath, 'Square1.jpg')))
        self.ui.square2Button.setIcon(QIcon(os.path.join(flatPath, 'Square2.jpg')))
        self.ui.pentagonButton.setIcon(QIcon(os.path.join(flatPath, 'Pentagon.jpg')))
        self.ui.starButton.setIcon(QIcon(os.path.join(flatPath, 'Star.jpg')))
        self.ui.crossButton.setIcon(QIcon(os.path.join(flatPath, 'Cross.jpg')))
        self.ui.flatCrossButton.setIcon(QIcon(os.path.join(flatPath, 'FlatCross.jpg')))
        self.ui.handButton.setIcon(QIcon(os.path.join(flatPath, 'Hand.jpg')))
        self.ui.footButton.setIcon(QIcon(os.path.join(flatPath, 'Foot.jpg')))
        self.ui.jackButton.setIcon(QIcon(os.path.join(flatPath, 'Jack.jpg')))
        #3D
        prismPath = os.path.join(self.currentDir, 'iconImg', '3D')
        self.ui.cubeButton.setIcon(QIcon(os.path.join(prismPath, 'Cube.jpg')))
        self.ui.octahedronButton.setIcon(QIcon(os.path.join(prismPath, 'Octahedron.jpg')))
        self.ui.sphereButton.setIcon(QIcon(os.path.join(prismPath, 'Sphere.jpg')))
        self.ui.halfSphereButton.setIcon(QIcon(os.path.join(prismPath, 'HalfSphere.jpg')))
        self.ui.piramidButton.setIcon(QIcon(os.path.join(prismPath, 'Piramid.jpg')))
        self.ui.piramid2Button.setIcon(QIcon(os.path.join(prismPath, 'Piramid2.jpg')))
        self.ui.locatorButton.setIcon(QIcon(os.path.join(prismPath, 'Locator.jpg')))
        #Arrow
        arrowPath = os.path.join(self.currentDir, 'iconImg', 'Arrow')
        self.ui.lineArrowButton.setIcon(QIcon(os.path.join(arrowPath, 'LineArrow.jpg')))
        self.ui.lineArrows2Button.setIcon(QIcon(os.path.join(arrowPath, 'LineArrows2.jpg')))
        self.ui.lineArrows4Button.setIcon(QIcon(os.path.join(arrowPath, 'LineArrows4.jpg')))
        self.ui.arrowButton.setIcon(QIcon(os.path.join(arrowPath, 'Arrow.jpg')))
        self.ui.arrowBoldButton.setIcon(QIcon(os.path.join(arrowPath, 'ArrowBold.jpg')))
        self.ui.arrows2Button.setIcon(QIcon(os.path.join(arrowPath, 'Arrows2.jpg')))
        self.ui.line90ArrowButton.setIcon(QIcon(os.path.join(arrowPath, 'LineArrow90.jpg')))
        self.ui.lineArrows180Button.setIcon(QIcon(os.path.join(arrowPath, 'LineArrows180.jpg')))
        self.ui.sideArrowsButton.setIcon(QIcon(os.path.join(arrowPath, 'SideArrows.jpg')))
        self.ui.sideArrows2Button.setIcon(QIcon(os.path.join(arrowPath, 'SideArrows2.jpg')))
        self.ui.roundArrowsButton.setIcon(QIcon(os.path.join(arrowPath, 'RoundArrows.jpg')))
        self.ui.roundArrows2Button.setIcon(QIcon(os.path.join(arrowPath, 'RoundArrows2.jpg')))
        self.ui.arrows4Button.setIcon(QIcon(os.path.join(arrowPath, 'Arrows4.jpg')))
        self.ui.arrows4sButton.setIcon(QIcon(os.path.join(arrowPath, 'Arrows4s.jpg')))

        #シグナル&スロットの設定
        #Create Rig
        self.ui.parentConstraintOnOff.stateChanged .connect(self.setParentConstraintEnable)
        self.ui.pointConstraintOnOff.stateChanged .connect(self.setPointOrientConstraintEnable)
        self.ui.orientConstraintOnOff.stateChanged .connect(self.setPointOrientConstraintEnable)
        self.ui.setConstraintButton.clicked.connect(self.setConstraint)
        #Select Icon
        #2D
        self.ui.circleButton.clicked.connect(lambda: self.selectIcon('Circle'))
        self.ui.crossCircleButton.clicked.connect(lambda: self.selectIcon('CrossCircle'))
        self.ui.circle270Button.clicked.connect(lambda: self.selectIcon('Circle270'))
        self.ui.circle180Button.clicked.connect(lambda: self.selectIcon('Circle180'))
        self.ui.square1Button.clicked.connect(lambda: self.selectIcon('Square1'))
        self.ui.square2Button.clicked.connect(lambda: self.selectIcon('Square2'))
        self.ui.pentagonButton.clicked.connect(lambda: self.selectIcon('Pentagon'))
        self.ui.starButton.clicked.connect(lambda: self.selectIcon('Star'))
        self.ui.crossButton.clicked.connect(lambda: self.selectIcon('Cross'))
        self.ui.flatCrossButton.clicked.connect(lambda: self.selectIcon('FlatCross'))
        self.ui.handButton.clicked.connect(lambda: self.selectIcon('Hand'))
        self.ui.footButton.clicked.connect(lambda: self.selectIcon('Foot'))
        self.ui.jackButton.clicked.connect(lambda: self.selectIcon('Jack'))
        #3D
        self.ui.cubeButton.clicked.connect(lambda: self.selectIcon('Cube'))
        self.ui.octahedronButton.clicked.connect(lambda: self.selectIcon('Octahedron'))
        self.ui.sphereButton.clicked.connect(lambda: self.selectIcon('Sphere'))
        self.ui.halfSphereButton.clicked.connect(lambda: self.selectIcon('HalfSphere'))
        self.ui.piramidButton.clicked.connect(lambda: self.selectIcon('Piramid'))
        self.ui.piramid2Button.clicked.connect(lambda: self.selectIcon('Piramid2'))
        self.ui.locatorButton.clicked.connect(lambda: self.selectIcon('Locator'))
        #Arrow
        self.ui.lineArrowButton.clicked.connect(lambda: self.selectIcon('LineArrow'))
        self.ui.lineArrows2Button.clicked.connect(lambda: self.selectIcon('LineArrows2'))
        self.ui.lineArrows4Button.clicked.connect(lambda: self.selectIcon('LineArrows4'))
        self.ui.arrowButton.clicked.connect(lambda: self.selectIcon('Arrow'))
        self.ui.arrowBoldButton.clicked.connect(lambda: self.selectIcon('ArrowBold'))
        self.ui.arrows2Button.clicked.connect(lambda: self.selectIcon('Arrows2'))
        self.ui.line90ArrowButton.clicked.connect(lambda: self.selectIcon('LineArrow90'))
        self.ui.lineArrows180Button.clicked.connect(lambda: self.selectIcon('LineArrows180'))
        self.ui.sideArrowsButton.clicked.connect(lambda: self.selectIcon('SideArrows'))
        self.ui.sideArrows2Button.clicked.connect(lambda: self.selectIcon('SideArrows2'))
        self.ui.roundArrowsButton.clicked.connect(lambda: self.selectIcon('RoundArrows'))
        self.ui.roundArrows2Button.clicked.connect(lambda: self.selectIcon('RoundArrows2'))
        self.ui.arrows4Button.clicked.connect(lambda: self.selectIcon('Arrows4'))
        self.ui.arrows4sButton.clicked.connect(lambda: self.selectIcon('Arrows4s'))
        #Rig Operation
        self.ui.rigSetButton.clicked.connect(self.createRigSet)
        self.ui.translateResetButton.clicked.connect(self.translateReset)
        self.ui.adjustRotateButton.clicked.connect(self.adjustRotate)
        self.ui.alignRigPivotToJointButton.clicked.connect(self.alignRigPivotToJoint)

        #IK Tool
        self.ui.ikButton.clicked.connect(self.createIk)
        self.ui.ikRigButton.clicked.connect(self.createIkRig)
        self.ui.reverseFootButton.clicked.connect(self.createReverseFoot)
        self.ui.dynamicChainButton.clicked.connect(self.createDynamicChain)

        #Other Tool
        self.ui.dummyJointButton.clicked.connect(self.createDummyJoint)
        self.ui.orientEndJointButton.clicked.connect(self.orientEndJoint)
        self.ui.parentJointToDummyButton.clicked.connect(self.parentJointToDummy)
        self.ui.centerPivotButton.clicked.connect(self.centerPivot)
        self.ui.freezeTRSButton.clicked.connect(self.freezeTRS)
        self.ui.colorResetButton.clicked.connect(self.colorReset)

    #COMO Tool
    #Create Rig
    '''
    parentConstraintOnOffに合わせて
    メニューを切り替えます
    '''
    def setParentConstraintEnable(self, flg):
        if flg:
            self.ui.pointConstraintOnOff.setEnabled(False)
            self.ui.orientConstraintOnOff.setEnabled(False)
        else:
            self.ui.pointConstraintOnOff.setEnabled(True)
            self.ui.orientConstraintOnOff.setEnabled(True)

    '''
    pointConstraintOnOff及びorientConstraintOnOffに合わせて
    メニューを切り替えます
    '''
    def setPointOrientConstraintEnable(self, flg):
        self.ui.parentConstraintOnOff.stateChanged .connect(self.setParentConstraintEnable)
        if flg:
            self.ui.parentConstraintOnOff.setEnabled(False)
        elif not self.ui.pointConstraintOnOff.isChecked() and not self.ui.orientConstraintOnOff.isChecked():
            self.ui.parentConstraintOnOff.setEnabled(True)

    '''
    選択したJointまたはRigにそれぞれ同名のRigまたはJointをコンストレインします
    '''
    def setConstraint(self):
        rigSuffix = self.ui.rigSuffixText.text()
        rootRig = ''.join([self.ui.rootText.text(), rigSuffix])
        spaceSuffix = self.ui.spaceSuffixText.text()
        dummyJointSuffix = self.ui.dummyJointSuffixText.text()
        parent = self.ui.parentConstraintOnOff.isChecked()
        point = self.ui.pointConstraintOnOff.isChecked()
        orient = self.ui.orientConstraintOnOff.isChecked()
        printItem = OrderedDict()
        printItem['rootRig'] = rootRig
        printItem['rigSuffix'] = rigSuffix
        printItem['spaceSuffix'] = spaceSuffix
        printItem['dummyJointSuffix'] = dummyJointSuffix
        printItem['parent'] = parent
        printItem['point'] = point
        printItem['orient'] = orient
        comoMessage.printDebugMessage('setConstraint',  printItem, level)
        comoMessage.printInfoMessage('setConstraint', level)
        rigTool.setConstraint(rootRig, rigSuffix, spaceSuffix, dummyJointSuffix, parent, point, orient)

    '''
    選択したIconでRigを作成します
    allJoint: 全てのジョイントを対象とします    otherToolpyHierarchy: 階層をコピーします
    Constraint: 選択したコンストレイントを設定します
    Change: 既存のRigを変更します
    '''
    def selectIcon(self, icon):
        root = self.ui.rootText.text()
        rigSuffix = self.ui.rigSuffixText.text()
        spaceSuffix = self.ui.spaceSuffixText.text()
        dummyJointSuffix = self.ui.dummyJointSuffixText.text()
        scale = cmds.floatSliderGrp('iconScaleSlider', q = True, value = True)
        allJoint = self.ui.allJointOnOff.isChecked()
        copyHierarchy = self.ui.copyHierarchyOnOff.isChecked()
        parent = self.ui.parentConstraintOnOff.isChecked()
        point = self.ui.pointConstraintOnOff.isChecked()
        orient = self.ui.orientConstraintOnOff.isChecked()
        change = self.ui.changeIconOnOff.isChecked()
        printItem = OrderedDict()
        printItem['rigSuffix'] = rigSuffix
        printItem['spaceSuffix'] = spaceSuffix
        printItem['dummyJointSuffix'] = dummyJointSuffix
        printItem['icon'] = icon
        printItem['scale'] = scale
        printItem['allJoint'] = allJoint
        printItem['copyHierarchy'] = copyHierarchy
        printItem['parent'] = parent
        printItem['point'] = point
        printItem['orient'] = orient
        printItem['change'] = change
        comoMessage.printDebugMessage('selectIcon',  printItem, level)
        comoMessage.printInfoMessage('selectIcon', level)
        rigTool.selectIcon(root, rigSuffix, spaceSuffix, dummyJointSuffix, icon, scale, allJoint, copyHierarchy, parent, point, orient, change)

    '''
    rigのsetを作成します
    '''
    def createRigSet(self):
        rigSuffix = self.ui.rigSuffixText.text()
        rootRig = ''.join([self.ui.rootText.text(), rigSuffix])
        spaceSuffix = self.ui.spaceSuffixText.text()
        printItem = OrderedDict()
        printItem['rootRig'] = rootRig
        printItem['rigSuffix'] = rigSuffix
        printItem['spaceSuffix'] = spaceSuffix
        comoMessage.printDebugMessage('createRigSet',  printItem, level)
        comoMessage.printInfoMessage('createRigSet', level)
        rigTool.createRigSet(rootRig, rigSuffix, spaceSuffix)

    '''
    rigのpivotをjointに合わせます
    '''
    def alignRigPivotToJoint(self):
        comoMessage.printInfoMessage('alignRigPivotToJoint', level)
        rigTool.alignRigPivotToJoint()

    '''
    選択オブジェクトをX方向に移動します
    '''
    def adjustTranslateX(self, x):
        self.adjustTranslate('x', x)
        cmds.intSliderGrp('adjustTranslateXSlider', e = True, value = 0)

    '''
    選択オブジェクトをY方向に移動します
    '''
    def adjustTranslateY(self, y):
        self.adjustTranslate('y', y)
        cmds.intSliderGrp('adjustTranslateYSlider', e = True, value = 0)

    '''
    選択オブジェクトをZ方向に移動します
    '''
    def adjustTranslateZ(self, z):
        self.adjustTranslate('z', z)
        cmds.intSliderGrp('adjustTranslateZSlider', e = True, value = 0)

    '''
    選択オブジェクトを任意の方向に移動します
    '''
    def adjustTranslate(self, direction, distance = 0):
        spaceSuffix = self.ui.spaceSuffixText.text()
        printItem = OrderedDict()
        printItem['spaceSuffix'] = spaceSuffix
        printItem['direction'] = direction
        printItem['distance'] = distance
        comoMessage.printDebugMessage('adjustTranslate',  printItem, level)
        comoMessage.printInfoMessage('adjustTranslate', level)
        adjustRig.adjustTranslate(spaceSuffix, direction, distance)

    '''
    選択オブジェクトをJointの位置に戻します
    '''
    def translateReset(self):
        spaceSuffix = self.ui.spaceSuffixText.text()
        printItem = OrderedDict()
        printItem['spaceSuffix'] = spaceSuffix
        comoMessage.printDebugMessage('translateReset',  printItem, level)
        comoMessage.printInfoMessage('translateReset', level)
        adjustRig.translateReset(spaceSuffix)

    '''
    選択オブジェクトを回転します
    '''
    def adjustRotate(self):
        spaceSuffix = self.ui.spaceSuffixText.text()
        rotate = self.ui.adjustRotateText.text()
        x = self.ui.rotateXRadioButton.isChecked()
        y = self.ui.rotateYRadioButton.isChecked()
        z = self.ui.rotateZRadioButton.isChecked()
        printItem = OrderedDict()
        printItem['spaceSuffix'] = spaceSuffix
        printItem['rotate'] = rotate
        printItem['x'] = x
        printItem['y'] = y
        printItem['z'] = z
        comoMessage.printDebugMessage('adjustRotate',  printItem, level)
        comoMessage.printInfoMessage('adjustRotate', level)
        try:
            adjustRig.adjustRotate(spaceSuffix, int(rotate), x, y, z)
        except:
            comoMessage.printInfoMessage('Please input angle. 0-360', level)

    '''
    選択したオブジェクトのサイズを変更します
    '''
    def adjustScale(self, scale):
        spaceSuffix = self.ui.spaceSuffixText.text()
        printItem = OrderedDict()
        printItem['spaceSuffix'] = spaceSuffix
        printItem['scale'] = scale
        comoMessage.printDebugMessage('adjustScale',  printItem, level)
        comoMessage.printInfoMessage('adjustScale', level)
        adjustRig.adjustScale(spaceSuffix, scale)
        cmds.floatSliderGrp('adjustScaleSlider', e = True, value = 1.0)

    #IK Tool
    '''
    HistoryTextをメニューにセットします
    '''
    def setJointSuffixHistoryMenu(self):
        #JointSuffixHistoryの読み込み
        if os.path.exists(self.jointSuffixHistoryFilePath):
            with open(self.jointSuffixHistoryFilePath, 'r') as settingFile:
                tempList = settingFile.readlines()
                self.jointSuffixHistoryList = [s.rstrip('\n') for s in tempList]
                comoMessage.printDebugMessage('jointSuffixHistoryList', self.jointSuffixHistoryList, level)

        if self.jointSuffixHistoryList:
            historyMenu = QMenu()
            try:
                historyMenu.addAction(self.jointSuffixHistoryList[0]).triggered.connect(lambda: self.setJointSuffixHistory(0))
                historyMenu.addAction(self.jointSuffixHistoryList[1]).triggered.connect(lambda: self.setJointSuffixHistory(1))
                historyMenu.addAction(self.jointSuffixHistoryList[2]).triggered.connect(lambda: self.setJointSuffixHistory(2))
                historyMenu.addAction(self.jointSuffixHistoryList[3]).triggered.connect(lambda: self.setJointSuffixHistory(3))
                historyMenu.addAction(self.jointSuffixHistoryList[4]).triggered.connect(lambda: self.setJointSuffixHistory(4))
                historyMenu.addAction(self.jointSuffixHistoryList[5]).triggered.connect(lambda: self.setJointSuffixHistory(5))
                historyMenu.addAction(self.jointSuffixHistoryList[6]).triggered.connect(lambda: self.setJointSuffixHistory(6))
                historyMenu.addAction(self.jointSuffixHistoryList[7]).triggered.connect(lambda: self.setJointSuffixHistory(7))
                historyMenu.addAction(self.jointSuffixHistoryList[8]).triggered.connect(lambda: self.setJointSuffixHistory(8))
                historyMenu.addAction(self.jointSuffixHistoryList[9]).triggered.connect(lambda: self.setJointSuffixHistory(9))
            except IndexError:
                pass
            self.ui.jointSuffixHistoryButton.setMenu(historyMenu)

    '''
    HistoryTextをフィールドにセットします
    '''
    def setJointSuffixHistory(self, i):
        self.ui.startJointSuffixText.setText(self.jointSuffixHistoryList[i].split(self.jointSuffixHistorySep)[0])
        self.ui.endJointSuffixText.setText(self.jointSuffixHistoryList[i].split(self.jointSuffixHistorySep)[1])

    '''
    Suffixで検索したJointにIkHandleを設定します
    '''
    def createIk(self):
        startJointSuffix = self.ui.startJointSuffixText.text()
        endJointSuffix = self.ui.endJointSuffixText.text()
        ikSuffix = self.ui.ikSuffixText.text()
        solver = 'ikRPsolver'
        if self.ui.ikSCSolverRadioButton.isChecked():
            solver = 'ikSCsolver'

        #settingファイルへの書き出し
        jointSuffix = self.jointSuffixHistorySep.join([startJointSuffix, endJointSuffix])
        if len(self.jointSuffixHistoryList) > 9:
            del self.jointSuffixHistoryList[10:]
        if jointSuffix in self.jointSuffixHistoryList:
            i = self.jointSuffixHistoryList.index(jointSuffix)
            del self.jointSuffixHistoryList[i]
        self.jointSuffixHistoryList.insert(0, jointSuffix)
        self.writeJointSuffixHistoryFile()

        #HistoryMenu更新
        self.setJointSuffixHistoryMenu()

        printItem = OrderedDict()
        printItem['startJointSuffix'] = startJointSuffix
        printItem['endJointSuffix'] = endJointSuffix
        printItem['ikSuffix'] = ikSuffix
        printItem['solver'] = solver
        comoMessage.printDebugMessage('createIk',  printItem, level)
        comoMessage.printInfoMessage('createIk', level)
        ikTool.createIk(startJointSuffix, endJointSuffix, ikSuffix, solver)

    '''
    選択したIkHandleにRigを設定します
    '''
    def createIkRig(self):
        rootRig = ''.join([self.ui.rootText.text(), self.ui.rigSuffixText.text()])
        spaceSuffix = self.ui.spaceSuffixText.text()
        dummyJointSuffix = self.ui.dummyJointSuffixText.text()
        poleSuffix = self.ui.poleVectorSuffixText.text()
        scale = cmds.floatSliderGrp('iconScaleSlider', q = True, value = True)
        rootVerFlg = self.ui.rootVersionOnOff.isChecked()
        printItem = OrderedDict()
        printItem['rootRig'] = rootRig
        printItem['spaceSuffix'] = spaceSuffix
        printItem['dummyJointSuffix'] = dummyJointSuffix
        printItem['poleSuffix'] = poleSuffix
        printItem['scale'] = scale
        printItem['rootVerFlg'] = rootVerFlg
        comoMessage.printDebugMessage('createIkRig',  printItem, level)
        comoMessage.printInfoMessage('createIkRig', level)
        ikTool.createIkRig(rootRig, spaceSuffix, dummyJointSuffix, poleSuffix, scale, rootVerFlg)

    '''
    足のjointにreversFoot用のIkとrigを作成します
    joint命名規則は下記の通りとします
    股関節:leg
    足首:ankle
    足指付け根:foot
    つま先:toe
    踵:heel
    '''
    def createReverseFoot(self):
        root = self.ui.rootText.text()
        legJoint = self.ui.legJointText.text()
        kneeJoint = self.ui.kneeJointText.text()
        ankleJoint = self.ui.ankleJointText.text()
        footJoint = self.ui.footJointText.text()
        toeJoint = self.ui.toeJointText.text()
        heelJoint = self.ui.heelJointText.text()
        rigSuffix = self.ui.rigSuffixText.text()
        spaceSuffix = self.ui.spaceSuffixText.text()
        dummyJointSuffix = self.ui.dummyJointSuffixText.text()
        ikSuffix = self.ui.ikSuffixText.text()
        poleSuffix = self.ui.poleVectorSuffixText.text()
        scale = cmds.floatSliderGrp('iconScaleSlider', q = True, value = True)
        printItem = OrderedDict()
        printItem['root'] = root
        printItem['legJoint'] = legJoint
        printItem['kneeJoint'] = kneeJoint
        printItem['ankleJoint'] = ankleJoint
        printItem['footJoint'] = footJoint
        printItem['toeJoint'] = toeJoint
        printItem['heelJoint'] = heelJoint
        printItem['rigSuffix'] = rigSuffix
        printItem['spaceSuffix'] = spaceSuffix
        printItem['dummyJointSuffix'] = dummyJointSuffix
        printItem['ikSuffix'] = ikSuffix
        printItem['poleSuffix'] = poleSuffix
        printItem['scale'] = scale
        comoMessage.printDebugMessage('createReverseFoot',  printItem, level)
        comoMessage.printInfoMessage('createReverseFoot', level)
        ikTool.createReverseFoot(root, legJoint, kneeJoint, ankleJoint, footJoint, toeJoint, heelJoint, rigSuffix, spaceSuffix, dummyJointSuffix, ikSuffix, poleSuffix, scale)

    '''
    選択した二カ所のJoint間にダイナミックチェインを設定します
    '''
    def createDynamicChain(self):
        comoMessage.printInfoMessage('createDynamicChain', level)
        dynamicChain.createDynamicChain()

    #Other Tool
    #Joint Tool
    '''
    リファレンスjointをコピーしてdummyJointを作成します
    作成したdummyJointにjointをペアレントします
    '''
    def createDummyJoint(self):
        dummyJointSuffix = self.ui.dummyJointSuffixText.text()
        printItem = OrderedDict()
        printItem['dummyJointSuffix'] = dummyJointSuffix
        comoMessage.printDebugMessage('createDummyJoint',  printItem, level)
        comoMessage.printInfoMessage('createDummyJoint', level)
        jointTool.createDummyJoint(dummyJointSuffix)

    '''
    dummyJointにjointをペアレントします
    '''
    def parentJointToDummy(self):
        dummyJointSuffix = self.ui.dummyJointSuffixText.text()
        printItem = OrderedDict()
        printItem['dummyJointSuffix'] = dummyJointSuffix
        comoMessage.printDebugMessage('parentJointToDummy',  printItem, level)
        comoMessage.printInfoMessage('parentJointToDummy', level)
        jointTool.parentJointToDummy(dummyJointSuffix)

    '''
    子のないjointのローカル軸を親jointに合わせます
    '''
    def orientEndJoint(self):
        comoMessage.printInfoMessage('orientEndJoint', level)
        jointTool.orientEndJoint()

    #Other
    '''
    選択オブジェクトのピボットをセンターに移動します
    '''
    def centerPivot(self):
        comoMessage.printInfoMessage('centerPivot',  level)
        otherTool.centerPivot()

    '''
    選択オブジェクトをフリーズします
    '''
    def freezeTRS(self):
        translate = self.ui.translateOnOff.isChecked()
        rotate = self.ui.rotateOnOff.isChecked()
        scale = self.ui.scaleOnOff.isChecked()
        printItem = OrderedDict()
        printItem['translate'] = translate
        printItem['rotate'] = rotate
        printItem['scale'] = scale
        comoMessage.printDebugMessage('freezeTRS',  printItem, level)
        comoMessage.printInfoMessage('freezeTRS', level)
        comoUtil.freezeTRS()

    '''
    メニューのインデックスと選択オブジェクトを指定色に変更します
    '''
    def changeColorPalette(self, index):
        self.changeColor(self.colorList[index])

    '''
    メニューのインデックスと選択オブジェクトを指定色に変更します
    '''
    def changeColorSlider(self, color):
        cmds.colorIndexSliderGrp('selectColorIndexSlider', edit = True, value = color + 1)
        self.changeColor(color)

    '''
    メニューのインデックスと選択オブジェクトの色をリセットします
    '''
    def colorReset(self):
        self.changeColor(0)

    '''
    メニューのインデックスと選択オブジェクトを指定色に変更します
    '''
    def changeColor(self, color):
        spaceSuffix = self.ui.spaceSuffixText.text()
        outliner = self.ui.outlinerOnOff.isChecked()
        printItem = OrderedDict()
        printItem['color'] = color
        printItem['spaceSuffix'] = spaceSuffix
        printItem['outliner'] = outliner
        comoMessage.printDebugMessage('changeColor',  printItem, level)
        comoMessage.printInfoMessage('changeColor', level)
        otherTool.changeColor(color, spaceSuffix, outliner)

    #処理系
    '''
    str型をbool型に変換します
    nullはFalseに変換します
    '''
    def boolConverter(self, value):
        comoMessage.printDebugMessage('boolConverter', value, level)
        if value == True or value == 'true':
            comoMessage.printDebugMessage('select', 'True', level)
            return True
        comoMessage.printDebugMessage('select', 'False', level)
        return False

    #Setting
    '''
    SettingFileへ書き込みます
    '''
    def writeJointSuffixHistoryFile(self):
        with open(self.jointSuffixHistoryFilePath, 'w') as settingFile:
            settingFile.writelines([''.join([history, '\n']) for history in self.jointSuffixHistoryList])

    def closeEvent(self, e):
        #Settingファイルへの書き込み
        iniSetting = QSettings(self.iniFilePath, QSettings.IniFormat)
        #CreateRig
        iniSetting.setValue('iconScaleSlider', cmds.floatSliderGrp('iconScaleSlider', q = True, value = True))
        iniSetting.setValue(self.ui.allJointOnOff.objectName(), self.ui.allJointOnOff.isChecked())
        iniSetting.setValue(self.ui.copyHierarchyOnOff.objectName(), self.ui.copyHierarchyOnOff.isChecked())
        iniSetting.setValue(self.ui.parentConstraintOnOff.objectName(), self.ui.parentConstraintOnOff.isChecked())
        iniSetting.setValue(self.ui.pointConstraintOnOff.objectName(), self.ui.pointConstraintOnOff.isChecked())
        iniSetting.setValue(self.ui.orientConstraintOnOff.objectName(), self.ui.orientConstraintOnOff.isChecked())
        iniSetting.setValue(self.ui.changeIconOnOff.objectName(), self.ui.changeIconOnOff.isChecked())
        #IK
        iniSetting.setValue(self.ui.startJointSuffixText.objectName(), self.ui.startJointSuffixText.text())
        iniSetting.setValue(self.ui.endJointSuffixText.objectName(), self.ui.endJointSuffixText.text())
        iniSetting.setValue(self.ui.ikRPSolverRadioButton.objectName(), self.ui.ikRPSolverRadioButton.isChecked())
        iniSetting.setValue(self.ui.ikSCSolverRadioButton.objectName(), self.ui.ikSCSolverRadioButton.isChecked())
        iniSetting.setValue(self.ui.rootVersionOnOff.objectName(), self.ui.rootVersionOnOff.isChecked())
        iniSetting.setValue(self.ui.legJointText.objectName(), self.ui.legJointText.text())
        iniSetting.setValue(self.ui.kneeJointText.objectName(), self.ui.kneeJointText.text())
        iniSetting.setValue(self.ui.ankleJointText.objectName(), self.ui.ankleJointText.text())
        iniSetting.setValue(self.ui.footJointText.objectName(), self.ui.footJointText.text())
        iniSetting.setValue(self.ui.toeJointText.objectName(), self.ui.toeJointText.text())
        iniSetting.setValue(self.ui.heelJointText.objectName(), self.ui.heelJointText.text())
        #Other
        iniSetting.setValue(self.ui.translateOnOff.objectName(), self.ui.translateOnOff.isChecked())
        iniSetting.setValue(self.ui.rotateOnOff.objectName(), self.ui.rotateOnOff.isChecked())
        iniSetting.setValue(self.ui.scaleOnOff.objectName(), self.ui.scaleOnOff.isChecked())
        iniSetting.setValue(self.ui.outlinerOnOff.objectName(), self.ui.outlinerOnOff.isChecked())
        #Setting
        iniSetting.setValue(self.ui.rootText.objectName(), self.ui.rootText.text())
        iniSetting.setValue(self.ui.rigSuffixText.objectName(), self.ui.rigSuffixText.text())
        iniSetting.setValue(self.ui.spaceSuffixText.objectName(), self.ui.spaceSuffixText.text())
        iniSetting.setValue(self.ui.dummyJointSuffixText.objectName(), self.ui.dummyJointSuffixText.text())
        iniSetting.setValue(self.ui.ikSuffixText.objectName(), self.ui.ikSuffixText.text())
        iniSetting.setValue(self.ui.poleVectorSuffixText.objectName(), self.ui.poleVectorSuffixText.text())

def showGui():
    if cmds.window('comoToolGui', exists = True):
        cmds.deleteUI('comoToolGui')
    ui = CreateNodeUI()
    ui.show()
    return ui
