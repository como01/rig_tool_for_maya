# -*- coding: utf-8 -*-

'''
COMO Tool comoUtil
'''

import re
import copy
from maya import cmds
from error.error import ArgumentError
from comoMessage import comoMessage

level = comoMessage.messageLevel

referenceSplit = ':'
pathSplit = '|'

'''
引数の文字列が数字の場合はそのまま、数字ではない場合は0を返します
'''
def checkNum(num):
    if re.match('[+|-]?\d', num):
        return num
    else:
        return 0

'''
リファレンスJointを除いた全てのJointのリストを返します
'''
def getJointListExcludingReference():
    return removeRefJoint(cmds.ls(type = 'joint'))


'''
引数のリストからリファレンスJointを除いて返します
'''
def removeRefJoint(ls):
    removeList = copy.copy(ls)
    if ls:
        refJointList = []
        try:
            cmds.select(''.join(['*', referenceSplit, '*']))
            refJointList = cmds.ls(sl = True, type = 'joint')
            cmds.select(clear = True)
        except ValueError:
            pass
        if refJointList:
            [removeList.remove(refJoint) for refJoint in refJointList if refJoint in removeList]
    return removeList

'''
引数のリストからコンストレイントを除いて返します
'''
def removeConstraint(ls):
    if ls:
        return [sel for sel in ls if not cmds.objectType(sel, isType = 'parentConstraint') and not cmds.objectType(sel, isType = 'pointConstraint') and not cmds.objectType(sel, isType = 'orientConstraint')]
    return []

'''
引数のリストから子を持たない要素を除いて返します
'''
def removeChildless(ls):
    if ls:
        return [sel for sel in ls if cmds.listRelatives(sel)]
    return []

'''
pathをpathSplitで分割し''を除いたリスト返します
'''
def getNodeList(path):
    nodeList = path.split(pathSplit)
    try:
        nodeList.remove('')
    except:
        pass
    return nodeList

'''
選択オブジェクトをフリーズします
'''
def freezeTRS(obj = '', translate = True, rotate = True, scale = True):
    if obj:
        cmds.makeIdentity(obj, apply = True, translate = translate, rotate = rotate, scale = scale)
    elif cmds.ls(sl = True):
        cmds.makeIdentity(apply = True, translate = translate, rotate = rotate, scale = scale)
    else:
        comoMessage.printInfoMessage('Nothing to Freeze', level)

'''
全てのrigのリストを返します
'''
def getRigList(rigRoot, rigSuffix, spaceSuffix):
    try:
        cmds.select(rigRoot, hierarchy = True)
    except ValueError:
        comoMessage.printWarningMessage('Please setting root.', '', level)
    try:
        cmds.select(cmds.ls(type = 'shape'), deselect = True)
        cmds.select(''.join(['*', rigSuffix, spaceSuffix]), deselect = True)
    except:
        pass
    rigList = cmds.ls(sl = True)
    cmds.select(clear = True)
    return rigList

'''
引数のリストから子を持つ要素を除いて返します
'''
def removeHaveChildrenElement(ls):
    if ls:
        return [sel for sel in ls if not cmds.listRelatives(sel)]
    return []

'''
引数のリストから名前にparamを含むオブジェクトを除いて返します
'''
def removeWithParameter(ls, param):
    if ls:
        return [sel for sel in ls if param not in sel]
    return []

'''
引数のオブジェクトを親、リストエレメントを子としてparentします
'''
def parentChildren(rig, childrenList):
    if childrenList:
        for children in childrenList:
            cmds.parent(children, rig)

'''
引数のRigとChildrenのparentを解除し、Childrenのリストを返します
'''
def parentChildrenToWorld(rig):
    childrenList = cmds.listRelatives(rig, type = 'transform')
    if childrenList:
        for children in childrenList:
            cmds.parent(children, world = True)
    return childrenList

'''
引数のRigに設定されているコンストレントを一つと種類を取得します
'''
def getConstraint(rig):
    constraint = ''
    parent = False
    point = False
    orient = False
    parentList = cmds.listConnections(rig, type='parentConstraint')
    if parentList:
        constraint = parentList[0]
        parent = True
    else:
        pointList = cmds.listConnections(rig, type='pointConstraint')
        if pointList:
            constraint = pointList[0]
            point = True
        orientList = cmds.listConnections(rig, type='orientConstraint')
        if orientList:
            constraint = orientList[0]
            orient = True
    return {'constraint': constraint, 'parent': parent, 'point': point, 'orient': orient}

'''
引数のRigとJointをコンストレントします
'''
def setConstraint(rig, joint, parent = False, point = False, orient = False, offset = True):
    try:
        if parent:
            cmds.parentConstraint(rig, joint, maintainOffset = offset)
        else:
            if point:
                cmds.pointConstraint(rig, joint, maintainOffset = offset)
            if orient:
                cmds.orientConstraint(rig, joint, maintainOffset = offset)
    except Exception as e:
        comoMessage.printWarningMessage(e, 'Constraint failed.', level)
        raise ArgumentError

'''
引数のRigとJointのコンストレイントを解除します
'''
def releaseConstraint(rig, joint, parent = False, point = False, orient = False):
    if parent:
        cmds.parentConstraint(rig, joint, e = True, remove = True)
        comoMessage.printDebugMessage('remove', 'parentConstraint', level)
    else:
        if point:
            cmds.pointConstraint(rig, joint, e = True, remove = True)
            comoMessage.printDebugMessage('remove', 'pointConstraint', level)
        if orient:
            cmds.orientConstraint(rig, joint, e = True, remove = True)
            comoMessage.printDebugMessage('remove', 'orientConstraint', level)
