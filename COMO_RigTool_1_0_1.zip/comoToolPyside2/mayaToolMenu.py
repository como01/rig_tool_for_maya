# -*- coding: utf-8 -*-

'''
COMO Tool mayaToolMenu
'''

import maya.cmds as cmds
from comoMessage import comoMessage

level = comoMessage.messageLevel

def main():
    cmds.evalDeferred("cmds.menu(label = 'Como Tool', parent = 'MayaWindow', tearOff = True, postMenuCommand = 'from comoToolPyside2.rig import comoToolGui; reload(comoToolGui); comoToolGui.showGui()')")
    comoMessage.printInfoMessage('Como Tool menu created.', level)
