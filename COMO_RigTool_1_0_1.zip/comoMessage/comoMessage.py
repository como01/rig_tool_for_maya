# -*- coding: utf-8 -*-

'''
COMO Tool comoMessage
'''

import re
import inspect
import traceback

messageLevelInfo = 0
messageLevelTraceback = 1
messageLevelDebug = 2

messageLevel = messageLevelInfo

printSep = ': '

'''
ファイル名を取得し、先頭の文字を大文字に、大文字の区切りの前にスペースを入れ、末尾の.pycを除去します
例:comoMessage.py → Como Message
'''
def getMessageName():
    stack = inspect.stack()
    stack0Name = stack[-1][1]
    stackSize = len(stack)
    fileName = stack0Name

    for i, s in enumerate(reversed(stack)):
        if stackSize - i == 4:
            break
        sName = s[1]
        if not sName == stack0Name:
            fileName = sName
            break

    rename = []
    for s in fileName.split('\\')[-1].rstrip('.pyc'):
        rename.append(re.sub(r'([A-Z])', ' ' + s, s))
    return ''.join(rename).title()

'''
メッセージのタイトルを取得します
例:* Como Message Info
'''
def getMessageTitle(attr):
    return '* {} {} Message'.format(getMessageName(), attr)

'''
メッセージを出力します
itemにはstr、配列、辞書を受け取ります
'''
def printMessage(attr, label, item):
    if not label:
        messageList = [getMessageTitle(attr), str(item)]
    elif isinstance(item, str):
        messageList = [getMessageTitle(attr), str(label), str(item)]
    elif isinstance(item, list):
        messageList = [getMessageTitle(attr), str(label)]
        for s in item:
            messageList.append(str(s))
    elif isinstance(item, dict):
        messageList = [getMessageTitle(attr), str(label), str(item)]
    else:
        messageList = [getMessageTitle(attr), str(label), str(item)]

    print(printSep.join(messageList))

'''
Infoメッセージを出力します
'''
def printInfoMessage(item, level):
    if level >= 0:
        printMessage('Info', '', item)
    if level >= 1:
        traceback.print_exc()

'''
Infoメッセージを出力します
itemにはstr、配列、辞書を受け取ります
'''
def printInfosMessage(label, item, level):
    if level >= 0:
        printMessage('Info', label, item)
    if level >= 1:
        traceback.print_exc()

'''
Warningメッセージを出力します
itemにはstr、配列、辞書を受け取ります
'''
def printWarningMessage(label, item, level):
    if level >= 0:
        printMessage('Warning', label, item)
    if level >= 1:
        traceback.print_exc()

'''
Debugメッセージを出力します
itemにはstr、配列、辞書を受け取ります
'''
def printDebugMessage(label, item, level):
    if level >= 2:
        printMessage('Debug', label, item)
        traceback.print_exc()
